from pathlib import Path
import requests
import pickle
import gzip
import torch
import torch.nn.functional as F
import numpy as np
from torch import nn
from torch import optim
from torch.utils.data import TensorDataset
from torch.utils.data import DataLoader

# Define character
batch_size = 64
lr = 0.1

# load data
DATA_PATH = Path("data")
PATH = DATA_PATH / "mnist"

PATH.mkdir(parents=True, exist_ok=True)

URL = "http://deeplearning.net/data/mnist/"
FILENAME = "mnist.pkl.gz"

if not (PATH / FILENAME).exists():
        content = requests.get(URL + FILENAME).content

with gzip.open((PATH / FILENAME).as_posix(), "rb") as f:
        ((x_train, y_train), (x_valid, y_valid), _) = pickle.load(f, encoding="latin-1")

# data transfer
x_train, x_valid, y_train, y_valid = map(torch.tensor, (x_train, x_valid, y_train, y_valid))

def get_data(train_ds, valid_ds, bs):
    return DataLoader(train_ds, batch_size=bs, shuffle=True), DataLoader(valid_ds, batch_size=bs*2)

train_ds = TensorDataset(x_train, y_train)
valid_ds = TensorDataset(x_valid, y_valid)

train_dl, valid_dl = get_data(train_ds, valid_ds, batch_size)

def proccess(x, y):
    return x.view(-1,1,28,28), y

class WrappedDataLoader():
    '''
    将数据的x每一个batch转换维度为：-1,1,28,28
    并输出为迭代器
    '''
    def __init__(self, dl, func):
        self.dl = dl
        self.func = func
    def __len__(self):
        return len(self.dl)
    def __iter__(self):
        batchs = iter(self.dl)
        for b in batchs:
            yield self.func(*b)

train_dl = WrappedDataLoader(train_dl, proccess)
valid_dl = WrappedDataLoader(valid_dl, proccess)

# model/loss_func/optim build
class Lambda(nn.Module):
    def __init__(self, func):
        super().__init__()
        self.func = func

    def forward(self, x):
        return self.func(x)

model = nn.Sequential(
    nn.Conv2d(1, 16, kernel_size=3, stride=2, padding=1),
    nn.ReLU(),
    nn.Conv2d(16, 16, kernel_size=3, stride=2, padding=1),
    nn.ReLU(),
    nn.Conv2d(16, 10, kernel_size=3, stride=2, padding=1),
    nn.ReLU(),
    nn.AvgPool2d(4),
    Lambda(lambda x: x.view(x.size(0), -1)) # lambda函数的语法只包含一个语句，如下：lambda arg1,arg2,..argn:expression
    )

loss_func = F.cross_entropy
opt = optim.SGD(model.parameters(), lr=lr)

# train and valid
def loss_batch(x, y, model, loss_f, optim=None):
    y_pred = model(x)
    loss = loss_f(y_pred, y)
    # combines log_softmax and nll_loss in a single
    if optim:
        loss.backward()
        optim.step()
        optim.zero_grad()
    return loss.item(), len(x)

def accuracy(y_p, y):
    '''
    caculate accuracy
    :param y_p: predict y
    :param y: target
    :return: the total number of correct y_p
    '''
    pred = torch.argmax(y_p, dim=1)
    return (pred == y).float().sum().item()

def fit(epochs, train, valid, model, loss, opt):

    for epoch in range(epochs):

        model.train()
        for x_train, y_train in train_dl:
            loss_batch(x_train, y_train, model, loss_func, opt)

        model.eval()
        with torch.no_grad():
            loss_valid, nums= zip(
                *[loss_batch(x_v, y_v, model,loss_func) for x_v, y_v in valid_dl]
            )
            val_acc = np.sum([accuracy(model(x_v), y_v) for x_v, y_v in valid_dl])/ np.sum(nums)

        val_loss = np.sum(np.multiply(loss_valid, nums))/ np.sum(nums)


        print('{}: val_loss={}, val_acc={} '.format(epoch, val_loss, val_acc))

fit(epochs=2, train=train_dl, valid=valid_dl, model=model, loss=loss_func, opt=opt)






