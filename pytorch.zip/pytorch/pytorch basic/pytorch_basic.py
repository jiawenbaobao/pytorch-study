import numpy as np
import torch

# creat a zero tensor
x = torch.Tensor(3, 4)
print('type: {}'.format(x.type()))
print('size: {}'.format(x.size()))
print('values: \n{}'.format(x))
'''
[out]:
type: torch.FloatTensor
size: torch.Size([3, 4])
values: 
tensor([[ 0.0000e+00, -2.5244e-29,  0.0000e+00, -2.5244e-29],
        [ 8.8397e-36,  1.4013e-45,  8.9499e-36,  1.4013e-45],
        [ 1.4850e-31,  1.4013e-45,  4.4029e-35,  1.4013e-45]])
'''

# creat a random tensor
x = torch.randn(3,4) 
print(x)
'''
[out]:
tensor([[ 0.3654, -0.7773, -2.0131,  0.7220],
        [-0.4503,  1.1270,  1.3365,  1.1962],
        [-0.9019,  0.2526, -0.0898,  0.0025]])
'''

# zeros and ones tensor
x = torch.zeros(2, 3)
x = torch.ones(2, 3)

# list -> tensor
x = torch.Tensor([[1,2],[3,4]])

# 矩阵相乘
x = torch.randn(2, 3)
y = torch.randn(3, 2)
z = torch.mm(x, y)
print('size: {}'.format(z.shape))
print('values: {}'.format(z))
'''
out:
size: torch.Size([2, 2])
values: tensor([[ 1.6538, -0.7923],
        [ 0.9657,  1.1785]])
'''

# 转置
x = torch.randn(2, 3)
y = torch.t(x)
print(y.shape)
'''
out:
torch.Size([3, 2])
'''

# reshape
x = torch.randn(2, 3)
z = x.view(3, 2)
print('x_size: {}'.format(x.shape))
print('z_size: {}'.format(z.shape))
'''
out:
x_size: torch.Size([2, 3])
z_size: torch.Size([3, 2])
'''

# reshape (unintended consequense)
x = torch.tensor([
    [[1,1,1,1], [2,2,2,2], [3,3,3,3]],
    [[10,10,10,10], [20,20,20,20], [30,30,30,30]]
])
y = x.view(x.shape[1], -1)
print('x_shape: {}'.format(x.shape))
print('y_shape: {}'.format(y.shape))
'''
out:
x_shape: torch.Size([2, 3, 4])
y_shape: torch.Size([3, 8])
'''

x = torch.randn(2, 3)
y = torch.sum(x, dim=0)
z = torch.sum(x, dim=1)
print('x: {}'.format(x))
print('y: {}'.format(y))
print('z: {}'.format(z))
'''
out:
x: tensor([[ 0.6222, -0.4158, -0.9900],
        [ 0.7905, -2.1140,  0.4939]])
y: tensor([ 1.4127, -2.5298, -0.4961])
z: tensor([-0.7836, -0.8296])
''' 

# splice
x = torch.randn(3,4)
print('x: {}'.format(x))
print('x[:1]\n{}'.format(x[:1]))
print('x[:1,1:3]\n{}'.format(x[:1,1:3]))
'''
out:
x: tensor([[-0.4740,  0.2828, -0.2289, -0.7612],
        [-2.1889,  0.0403,  1.4711, -0.3404],
        [-0.3078, -0.9475,  0.2974,  0.7882]])
x[:1]
tensor([[-0.4740,  0.2828, -0.2289, -0.7612]])
x[:1,1:3]
tensor([[ 0.2828, -0.2289]])
'''

# concat
x = torch.randn(2, 3)
y = torch.cat([x, x], dim=0) # 按行连接
print(x)
print(y)
'''
out:
tensor([[2.1663, 2.0004, 0.5490],
        [0.7599, 0.3662, 1.9184]])
tensor([[2.1663, 2.0004, 0.5490],
        [0.7599, 0.3662, 1.9184],
        [2.1663, 2.0004, 0.5490],
        [0.7599, 0.3662, 1.9184]])
'''

# gradient
x = torch.randn(2, 3, requires_grad=True)
y = 3 * x + 2
z = y.mean()
z.backward()
print('x:{}'.format(x))
print('x.grad:{}'.format(x.grad))
'''
out:
x:tensor([[-2.2951,  0.7744, -0.3490],
        [-0.2814, -0.5622,  0.7669]], requires_grad=True)
x.grad:tensor([[0.5000, 0.5000, 0.5000],
        [0.5000, 0.5000, 0.5000]])
'''



















































































